package com.stevenhornghub.promotionrequest.exceptions.message;

public class CustomMessage {

    public static final String NO_RECORD_FOUND = "No record found for given value: ";
    public static final String DELETE_SUCCESS_MESSAGE = " has been deleted successfully for the given value: ";


}
