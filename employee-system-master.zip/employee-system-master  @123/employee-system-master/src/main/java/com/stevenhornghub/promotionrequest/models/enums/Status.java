package com.stevenhornghub.promotionrequest.models.enums;

public enum Status {
    APPROVED,
    DISAPPROVED,
    PENDING
}
