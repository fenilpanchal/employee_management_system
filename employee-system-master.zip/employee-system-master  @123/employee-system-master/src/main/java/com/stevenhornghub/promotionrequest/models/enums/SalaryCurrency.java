package com.stevenhornghub.promotionrequest.models.enums;

public enum SalaryCurrency {
    USD,
    PHP,
    RMB,
    USDT
}
