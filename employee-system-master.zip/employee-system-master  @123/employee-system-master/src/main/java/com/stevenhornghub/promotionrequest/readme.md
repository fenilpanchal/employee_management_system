This Employee System is an open source project built using Java, 
Springboot, SQL and JPA. It provides an intuitive and secure interface for managing employee data and records. 
The system is customisable, with features like search and sort, payroll, authentication and more.
With a full lifecycle overview, it is the perfect tool for businesses looking for an efficient way to track employee information.