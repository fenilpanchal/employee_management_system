package com.stevenhornghub.promotionrequest.exceptions;

public class CannotBeNullException extends RuntimeException {
    public CannotBeNullException(String message) {
        super(message);
    }
}
