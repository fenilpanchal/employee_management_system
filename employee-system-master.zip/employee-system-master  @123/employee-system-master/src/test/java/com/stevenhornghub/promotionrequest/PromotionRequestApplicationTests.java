package com.stevenhornghub.promotionrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PromotionRequestApplicationTests {

    @Test
    void contextLoads() {
    }

}
