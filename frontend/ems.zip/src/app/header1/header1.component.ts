
import { HttpClient } from '@angular/common/http';
import { Component, Injectable } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-header1',
  standalone: true,
  imports: [
    RouterLink, RouterLinkActive
  ],
  templateUrl: './header1.component.html',
  styleUrl: './header1.component.scss'
})
@Injectable({
  providedIn: 'root'
})

export class Header1Component {
  
login: any;

//   private apiurl='http://localhost:8080/employee/add/update';
//   constructor (private http: HttpClient){}
//   putAllEmployee():Observable<add/employee[any]>{
//     return this.httpClient.post<add/[any]>(apiurl);
//   }
}

