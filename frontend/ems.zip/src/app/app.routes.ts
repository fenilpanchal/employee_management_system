
import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeComponent } from './employee/employee.component';


import { AppComponent } from './app.component';

export const routes: Routes =  [ 
  // { path: '', loadChildren: () => import('./dashboard/dashboard.module').then(mod => mod.DashboardModule), },
  { path: '', component: DashboardComponent},
  { path: 'login', loadChildren: () => import('./home/login/login.module').then(mod => mod.LoginModule) },
  // { path: 'signup', loadChildren: () => import('./home/signup/signup.module').then(mod => mod.SignupModule)},
  { path: 'employee',component:EmployeeComponent},
  {path:'app',component : AppComponent}
  
]  