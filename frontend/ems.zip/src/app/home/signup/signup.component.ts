// import { HttpClientModule } from '@angular/common/http';
// import { Component, OnInit } from '@angular/core'; 
// import { ClientsComponent } from '../../header1/clients/clients.component';

// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { User } from '../../dto/user';
// import { Service } from '../../service';
// import { Router } from '@angular/router';

// @Component({
//     selector: 'app-signup',
//     standalone: true,
//     templateUrl: './signup.component.html',
//     styleUrl: './signup.component.scss',
//     imports: [
//         ClientsComponent,
//         HttpClientModule,
//         FormsModule,
//         ReactiveFormsModule,
//         SignupComponent
//     ],
//     providers: [HttpClientModule, Service],
// })
// export class SignupComponent implements OnInit {
//     user:User=new User();

//     constructor (private service:Service, private route:Router) {}

//     ngOnInit(): void {}
//         save(){
//             console.log("user registration successfully")
//             this.service.signupuser(this.user)
//             .subscribe((data) => {
//                 console.info(data);
//                 // Redirect to another page
//                 // this.route.navigate(['/']);
//                 this.route.navigateByUrl("/login");
//                 alert(" Registration Will Be successfully");
//             },(error) => {
//                 console.error(error);
//       }) ;  
//     }
//     f1(){
//         this.route.navigateByUrl("/login")
//     }
// }

